
<?php
if($_SERVER['REQUEST_METHOD']== "post"){

if (empty($POST['username'])){
    $username_error = "Can't submit without the username. Please enter";
}
 if (empty($POST['password'])){
    $password_error = "Can't submit without the password. Please enter";
}

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Practice</title>
</head>
<body>
    <form method ="post" action="" auto_complete="off">
        <input type="text" name="username"  id="">
        <span><?php if(isset($username_error)) echo $username_error;?></span>
        <input type="password" name="password"  id="">
        <span><?php if(isset($password_error)) echo $password_error ;?></span>
        <input type="submit" value="Register"  id="">
    </form>
</body>
</html>