<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPU Admission Form Online</title>

    <style>
        .bfClearfix:after {
        content: ".";
        display: block;
        height: 0;
        clear: both;
        visibility: hidden;
        }
        .bfInline{
        float:left;
        }
        .bfFadingClass{
        display:none;
        }
            h1, h2, h3, h4, h5, h6, .site-title{
                font-family: Arial, Helvetica, sans-serif;
            }
            body.site {
                border-top: 0px solid #1c0303;
                background-color: #f4f6f7;
            }
            a {
                color: #1c0303;
            }
           
        div.mod_search87 input[type="search"]{ width:auto; }
            </style>

</head>
<body>


    <form data-ajax="false"  action="https://www.spu.ac.ke/new/index.php/apply-online" method="post" name="ff_form1" id="ff_form1" enctype="multipart/form-data" accept-charset="utf-8" onsubmit="return false;" class="bfQuickMode">
        <div id="bfPage1" class="bfPage">
        <section class="bfPageIntro">
        <p style="text-align: center;"><strong><span style="font-size: medium;">APPLICATION FOR ADMISSION</span></strong></p>
        <p><strong><span style="font-size: medium;">APPLICATION PROCEDURE</span></strong><span style="font-size: 12.16px; line-height: 1.3em;"> </span></p>
        <ol>
        <li>Attach photocopies of all academic and professional certificates. If they are not in English send translated and certified<br />copies. Non-English speakers must provide proof of competence in English.</li>
        <li>Attach a copy of your recent coloured passport size photographs.</li>
        <li>Please note that you are required to pay a non refundable application fee for your application to be processed.
        <ul>
        <li>Postgraduate Application Fee- KSh.3,000.00</li>
        <li>Undergraduate Application Fee- KSh. 1,500.00</li>
        <li>Diploma &amp; Certificate Application Fee- KSh. 1,000.00<span style="font-size: 12.16px; line-height: 1.3em;"> </span></li>
        <li>You can deposit the application fee in any of our bank accounts and then scan and attach the bank slip here. <a href="/new/bank-account-details" rel="alternate">Click here to view bank account details.</a></li>
        </ul>
        </li>
        </ol>
        </section>
        <span class="bfErrorMessage" style="display:none"></span>
        <div class="bfFieldset-wrapper bfWrapperBlock bfClearfix"><div class="bfFieldset-tl"><div class="bfFieldset-tr"><div class="bfFieldset-t"></div></div></div><div class="bfFieldset-l"><div class="bfFieldset-r"><div class="bfFieldset-m bfClearfix"><fieldset class="bfBlock" id="Personalinformation">
        <legend><span class="bfLegend-l"><span class="bfLegend-r"><span class="bfLegend-m">Personal Information</span></span></span></legend>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap21">
        <label id="bfLabel21" for="ff_elem21">First name<span class="bfRequired">*</span> 
        </label>
        <input class="ff_elem" type="text" name="ff_nm_Firstname[]" value="" id="ff_elem21"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap26">
        <label id="bfLabel26" for="ff_elem26">Middle name</label>
        <input class="ff_elem" type="text" name="ff_nm_Middlename[]" value="" id="ff_elem26"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap27">
        <label id="bfLabel27" for="ff_elem27">Last name<span class="bfRequired">*</span> 
        </label>
        <input class="ff_elem" type="text" name="ff_nm_Lastname[]" value="" id="ff_elem27"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap32">
        <label id="bfLabel32" for="ff_elem32">Date of birth<span class="bfRequired">*</span> 
        </label>
        <span class="bfElementGroupNoWrap" id="bfElementGroupNoWrap32">
        <input autocomplete="off" class="ff_elem bfCalendarInput" style="width: 65%;min-width: 65%;max-width: 65%;" type="text" name="ff_nm_Dateofbirth[]"  id="ff_elem32" value=""/>
        <button type="button" id="ff_elem32_calendarButton" type="submit" class="bfCalendar" value="..."><span>...</span></button>
        </span>
                    
    <section class="bfElemWrap bfLabelLeft" id="bfElemWrap33">
        <label id="bfLabel33" for="ff_elem33">Citizenship<span class="bfRequired">*</span> 
        </label>
        <input class="ff_elem" type="text" name="ff_nm_Citizenship[]" value="" id="ff_elem33"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap58">
        <label id="bfLabel58" for="ff_elem58">Country of birth<span class="bfRequired">*</span> 
        </label>
        <select data-chosen="no-chzn" class="ff_elem chzn-done" name="ff_nm_Country[]" id="ff_elem58">
        <option value="">-Select country-</option>
        <option value="Afghanistan">Afghanistan</option>
        <option value="Albania">Albania</option>
        <option value="Algeria">Algeria</option>
        <option value="Andorra">Andorra</option>
        <option value="Angola">Angola</option>
        <option value="Antigua and Barbuda">Antigua and Barbuda</option>
        <option value="Argentina">Argentina</option>
        <option value="Armenia">Armenia</option>
        <option value="Australia">Australia</option>
        <option value="Austria">Austria</option>
        <option value="Azerbaijan">Azerbaijan</option>
        <option value="Bahamas">Bahamas</option>
        <option value="Bahrain">Bahrain</option>
        <option value="Bangladesh">Bangladesh</option>
        <option value="Barbados">Barbados</option>
        <option value="Belarus">Belarus</option>
        <option value="Belgium">Belgium</option>
        <option value="Belize">Belize</option>
        <option value="Benin">Benin</option>
        <option value="Bhutan">Bhutan</option>
        <option value="Bolivia">Bolivia</option>
        <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
        <option value="Botswana">Botswana</option>
        <option value="Brazil">Brazil</option>
        <option value="Brunei">Brunei</option>
        <option value="Bulgaria">Bulgaria</option>
        <option value="Burkina Faso">Burkina Faso</option>
        <option value="Burundi">Burundi</option>
        <option value="Cambodia">Cambodia</option>
        <option value="Cameroon">Cameroon</option>
        <option value="Canada">Canada</option>
        <option value="Cape Verde">Cape Verde</option>
        <option value="Central African Republic">Central African Republic</option>
        <option value="Chad">Chad</option>
        <option value="Chile">Chile</option>
        <option value="China">China</option>
        <option value="Colombia">Colombia</option>
        <option value="Comoros">Comoros</option>
        <option value="Congo (Brazzaville)">Congo (Brazzaville)</option>
        <option value="Congo">Congo</option>
        <option value="Costa Rica">Costa Rica</option>
        <option value="Cote d&#039;Ivoire">Cote d&#039;Ivoire</option>
        <option value="Croatia">Croatia</option>
        <option value="Cuba">Cuba</option>
        <option value="Cyprus">Cyprus</option>
        <option value="Czech Republic">Czech Republic</option>
        <option value="Denmark">Denmark</option>
        <option value="Djibouti">Djibouti</option>
        <option value="Dominica">Dominica</option>
        <option value="Dominican Republic">Dominican Republic</option>
        <option value="East Timor (Timor Timur)">East Timor (Timor Timur)</option>
        <option value="Ecuador">Ecuador</option>
        <option value="Egypt">Egypt</option>
        <option value="El Salvador">El Salvador</option>
        <option value="Equatorial Guinea">Equatorial Guinea</option>
        <option value="Eritrea">Eritrea</option>
        <option value="Estonia">Estonia</option>
        <option value="Ethiopia">Ethiopia</option>
        <option value="Fiji">Fiji</option>
        <option value="Finland">Finland</option>
        <option value="France">France</option>
        <option value="Gabon">Gabon</option>
        <option value="Gambia">Gambia</option>
        <option value="Georgia">Georgia</option>
        <option value="Germany">Germany</option>
        <option value="Ghana">Ghana</option>
        <option value="Greece">Greece</option>
        <option value="Grenada">Grenada</option>
        <option value="Guatemala">Guatemala</option>
        <option value="Guinea">Guinea</option>
        <option value="Guinea-Bissau">Guinea-Bissau</option>
        <option value="Guyana">Guyana</option>
        <option value="Haiti">Haiti</option>
        <option value="Honduras">Honduras</option>
        <option value="Hungary">Hungary</option>
        <option value="Iceland">Iceland</option>
        <option value="India">India</option>
        <option value="Indonesia">Indonesia</option>
        <option value="Iran">Iran</option>
        <option value="Iraq">Iraq</option>
        <option value="Ireland">Ireland</option>
        <option value="Israel">Israel</option>
        <option value="Italy">Italy</option>
        <option value="Jamaica">Jamaica</option>
        <option value="Japan">Japan</option>
        <option value="Jordan">Jordan</option>
        <option value="Kazakhstan">Kazakhstan</option>
        <option selected="selected" value="Kenya">Kenya</option>
        <option value="Kiribati">Kiribati</option>
        <option value="Korea, North">Korea, North</option>
        <option value="Korea, South">Korea, South</option>
        <option value="Kuwait">Kuwait</option>
        <option value="Kyrgyzstan">Kyrgyzstan</option>
        <option value="Laos">Laos</option>
        <option value="Latvia">Latvia</option>
        <option value="Lebanon">Lebanon</option>
        <option value="Lesotho">Lesotho</option>
        <option value="Liberia">Liberia</option>
        <option value="Libya">Libya</option>
        <option value="Liechtenstein">Liechtenstein</option>
        <option value="Lithuania">Lithuania</option>
        <option value="Luxembourg">Luxembourg</option>
        <option value="Macedonia">Macedonia</option>
        <option value="Madagascar">Madagascar</option>
        <option value="Malawi">Malawi</option>
        <option value="Malaysia">Malaysia</option>
        <option value="Maldives">Maldives</option>
        <option value="Mali">Mali</option>
        <option value="Malta">Malta</option>
        <option value="Marshall Islands">Marshall Islands</option>
        <option value="Mauritania">Mauritania</option>
        <option value="Mauritius">Mauritius</option>
        <option value="Mexico">Mexico</option>
        <option value="Micronesia">Micronesia</option>
        <option value="Moldova">Moldova</option>
        <option value="Monaco">Monaco</option>
        <option value="Mongolia">Mongolia</option>
        <option value="Morocco">Morocco</option>
        <option value="Mozambique">Mozambique</option>
        <option value="Myanmar">Myanmar</option>
        <option value="Namibia">Namibia</option>
        <option value="Nauru">Nauru</option>
        <option value="Nepa">Nepa</option>
        <option value="Netherlands">Netherlands</option>
        <option value="New Zealand">New Zealand</option>
        <option value="Nicaragua">Nicaragua</option>
        <option value="Niger">Niger</option>
        <option value="Nigeria">Nigeria</option>
        <option value="Norway">Norway</option>
        <option value="Oman">Oman</option>
        <option value="Pakistan">Pakistan</option>
        <option value="Palau">Palau</option>
        <option value="Panama">Panama</option>
        <option value="Papua New Guinea">Papua New Guinea</option>
        <option value="Paraguay">Paraguay</option>
        <option value="Peru">Peru</option>
        <option value="Philippines">Philippines</option>
        <option value="Poland">Poland</option>
        <option value="Portugal">Portugal</option>
        <option value="Qatar">Qatar</option>
        <option value="Romania">Romania</option>
        <option value="Russia">Russia</option>
        <option value="Rwanda">Rwanda</option>
        <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
        <option value="Saint Lucia">Saint Lucia</option>
        <option value="Saint Vincent">Saint Vincent</option>
        <option value="Samoa">Samoa</option>
        <option value="San Marino">San Marino</option>
        <option value="Sao Tome and Principe">Sao Tome and Principe</option>
        <option value="Saudi Arabia">Saudi Arabia</option>
        <option value="Senegal">Senegal</option>
        <option value="Serbia and Montenegro">Serbia and Montenegro</option>
        <option value="Seychelles">Seychelles</option>
        <option value="Sierra Leone">Sierra Leone</option>
        <option value="Singapore">Singapore</option>
        <option value="Slovakia">Slovakia</option>
        <option value="Slovenia">Slovenia</option>
        <option value="Solomon Islands">Solomon Islands</option>
        <option value="Somalia">Somalia</option>
        <option value="South Africa">South Africa</option>
        <option value="Spain">Spain</option>
        <option value="Sri Lanka">Sri Lanka</option>
        <option value="Sudan">Sudan</option>
        <option value="Suriname">Suriname</option>
        <option value="Swaziland">Swaziland</option>
        <option value="Sweden">Sweden</option>
        <option value="Switzerland">Switzerland</option>
        <option value="Syria">Syria</option>
        <option value="Taiwan">Taiwan</option>
        <option value="Tajikistan">Tajikistan</option>
        <option value="Tanzania">Tanzania</option>
        <option value="Thailand">Thailand</option>
        <option value="Togo">Togo</option>
        <option value="Tonga">Tonga</option>
        <option value="Trinidad and Tobago">Trinidad and Tobago</option>
        <option value="Tunisia">Tunisia</option>
        <option value="Turkey">Turkey</option>
        <option value="Turkmenistan">Turkmenistan</option>
        <option value="Tuvalu">Tuvalu</option>
        <option value="Uganda">Uganda</option>
        <option value="Ukraine">Ukraine</option>
        <option value="United Arab Emirates">United Arab Emirates</option>
        <option value="United Kingdom">United Kingdom</option>
        <option value="United States">United States</option>
        <option value="Uruguay">Uruguay</option>
        <option value="Uzbekistan">Uzbekistan</option>
        <option value="Vanuatu">Vanuatu</option>
        <option value="Vatican City">Vatican City</option>
        <option value="Venezuela">Venezuela</option>
        <option value="Vietnam">Vietnam</option>
        <option value="Yemen">Yemen</option>
        <option value="Zambia">Zambia</option>
        <option value="Zimbabwe">Zimbabwe</option>
        </select>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap35">
        <label id="bfLabel35" for="ff_elem35">County of birth<span class="bfRequired">*</span> 
        </label>
        <input class="ff_elem" type="text" name="ff_nm_Countyofbirth[]" value="" id="ff_elem35"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap78">
        <label id="bfLabel78" for="ff_elem78">ID / Passport number</label>
        <input class="ff_elem" type="text" name="ff_nm_IDNO[]" value="" id="ff_elem78"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap53">
        <label id="bfLabel53" for="ff_elem53">Gender<span class="bfRequired">*</span> 
        </label>
        <span class="bfElementGroupNoWrap" id="bfElementGroupNoWrap53">
        <input  class="ff_elem" type="checkbox" name="ff_nm_Gender[]" value="Male" id="ff_elem53"/><label class="bfGroupLabel" id="bfGroupLabel53" for="ff_elem53">Male</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_Gender[]" value="Female" id="ff_elem53_1"/><label class="bfGroupLabel" id="bfGroupLabel53_1" for="ff_elem53_1">Female</label>
        </span>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap59">
        <label id="bfLabel59" for="ff_elem59">Years of Formal Education in English<span class="bfRequired">*</span> 
        </label>
        <input class="ff_elem" type="text" name="ff_nm_Education[]" value="" id="ff_elem59"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap68">
        <label id="bfLabel68" for="ff_elem68">Highest Level of education<span class="bfRequired">*</span> 
        </label>
        <span class="bfElementGroupNoWrap" id="bfElementGroupNoWrap68">
        <input  class="ff_elem" type="checkbox" name="ff_nm_EducationLevel[]" value="primary" id="ff_elem68"/><label class="bfGroupLabel" id="bfGroupLabel68" for="ff_elem68">Primary</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_EducationLevel[]" value="seconadry" id="ff_elem68_1"/><label class="bfGroupLabel" id="bfGroupLabel68_1" for="ff_elem68_1">Secondary</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_EducationLevel[]" value="postgraduate" id="ff_elem68_2"/><label class="bfGroupLabel" id="bfGroupLabel68_2" for="ff_elem68_2">Postgraduate</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_EducationLevel[]" value="others" id="ff_elem68_3"/><label class="bfGroupLabel" id="bfGroupLabel68_3" for="ff_elem68_3">Others</label>
        </span>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap69">
        <label id="bfLabel69" for="ff_elem69">If others, please specify</label>
        <textarea cols="20" rows="5" class="ff_elem" name="ff_nm_Specification[]" id="ff_elem69"></textarea>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap79">
        <label id="bfLabel79" for="ff_elem79">Upload passport size photo<span class="bfRequired">*</span> 
        </label>
        <input class="ff_elem" type="file" name="ff_nm_Passportphoto[]" id="ff_elem79"/>
        <span id="ff_elem79_files"></span></section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap80">
        <label id="bfLabel80" for="ff_elem80">Other Languages spoken or written<span class="bfRequired">*</span> 
        </label>
        <input class="ff_elem" type="text" name="ff_nm_Languages[]" value="" id="ff_elem80"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap81">
        <label id="bfLabel81" for="ff_elem81">Do you have any disability<span class="bfRequired">*</span> 
        </label>
        <span class="bfElementGroupNoWrap" id="bfElementGroupNoWrap81">
        <input  class="ff_elem" type="checkbox" name="ff_nm_Disbility[]" value="yes" id="ff_elem81"/><label class="bfGroupLabel" id="bfGroupLabel81" for="ff_elem81">Yes</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_Disbility[]" value="no" id="ff_elem81_1"/><label class="bfGroupLabel" id="bfGroupLabel81_1" for="ff_elem81_1">No</label>
        </span>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap86">
        <label id="bfLabel86" for="ff_elem86">If yes, Please explain nature of disability</label>
        <textarea cols="20" rows="5" class="ff_elem" name="ff_nm_Disbilitynature[]" id="ff_elem86"></textarea>
        </section>
        </fieldset></div></div></div><div class="bfFieldset-bl"><div class="bfFieldset-br"><div class="bfFieldset-b"></div></div></div></div><!-- bfFieldset-wrapper end -->
        <div class="bfFieldset-wrapper bfWrapperBlock bfClearfix"><div class="bfFieldset-tl"><div class="bfFieldset-tr"><div class="bfFieldset-t"></div></div></div><div class="bfFieldset-l"><div class="bfFieldset-r"><div class="bfFieldset-m bfClearfix"><fieldset class="bfBlock" id="Religious">
        <legend><span class="bfLegend-l"><span class="bfLegend-r"><span class="bfLegend-m">Religious affiliation</span></span></span></legend>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap110">
        <label id="bfLabel110" for="ff_elem110">Religious Affiliation</label>
        <span class="bfElementGroupNoWrap" id="bfElementGroupNoWrap110">
        <input  class="ff_elem" type="radio" name="ff_nm_Religious[]" value="protestant" id="ff_elem110"/><label class="bfGroupLabel" id="bfGroupLabel110" for="ff_elem110">Protestant</label>
        <input checked="checked"  class="ff_elem" type="radio" name="ff_nm_Religious[]" value="roman Catholic" id="ff_elem110_1"/><label class="bfGroupLabel" id="bfGroupLabel110_1" for="ff_elem110_1">Roman Catholic</label>
        <input  class="ff_elem" type="radio" name="ff_nm_Religious[]" value="hindu" id="ff_elem110_2"/><label class="bfGroupLabel" id="bfGroupLabel110_2" for="ff_elem110_2">Hindu</label>
        <input  class="ff_elem" type="radio" name="ff_nm_Religious[]" value="African Traditional Religion" id="ff_elem110_3"/><label class="bfGroupLabel" id="bfGroupLabel110_3" for="ff_elem110_3">African Traditional Religion</label>
        <input  class="ff_elem" type="radio" name="ff_nm_Religious[]" value="muslim" id="ff_elem110_4"/><label class="bfGroupLabel" id="bfGroupLabel110_4" for="ff_elem110_4">Muslim</label>
        <input  class="ff_elem" type="radio" name="ff_nm_Religious[]" value="ordained minister" id="ff_elem110_5"/><label class="bfGroupLabel" id="bfGroupLabel110_5" for="ff_elem110_5">Ordained Minister (For Divinity Applicants only)</label>
        <input  class="ff_elem" type="radio" name="ff_nm_Religious[]" value="other" id="ff_elem110_6"/><label class="bfGroupLabel" id="bfGroupLabel110_6" for="ff_elem110_6">Other(Please specify)</label>
        </span>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap119">
        <label id="bfLabel119" for="ff_elem119">Specify religious affiliation</label>
        <textarea cols="20" rows="5" class="ff_elem" name="ff_nm_Specifyreligion[]" id="ff_elem119"></textarea>
        </section>
        </fieldset></div></div></div><div class="bfFieldset-bl"><div class="bfFieldset-br"><div class="bfFieldset-b"></div></div></div></div><!-- bfFieldset-wrapper end -->
        <div class="bfFieldset-wrapper bfWrapperBlock bfClearfix"><div class="bfFieldset-tl"><div class="bfFieldset-tr"><div class="bfFieldset-t"></div></div></div><div class="bfFieldset-l"><div class="bfFieldset-r"><div class="bfFieldset-m bfClearfix"><fieldset class="bfBlock" id="Address">
        <legend><span class="bfLegend-l"><span class="bfLegend-r"><span class="bfLegend-m">Current Address</span></span></span></legend>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap91">
        <label id="bfLabel91" for="ff_elem91">Postal address<span class="bfRequired">*</span> 
        </label>
        <input class="ff_elem" type="text" name="ff_nm_Postaladdress[]" value="" id="ff_elem91"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap92">
        <label id="bfLabel92" for="ff_elem92">Postal Code</label>
        <input class="ff_elem" type="text" name="ff_nm_Code[]" value="" id="ff_elem92"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap93">
        <label id="bfLabel93" for="ff_elem93">Town<span class="bfRequired">*</span> 
        </label>
        <input class="ff_elem" type="text" name="ff_nm_Town[]" value="" id="ff_elem93"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap94">
        <label id="bfLabel94" for="ff_elem94">Country</label>
        <input class="ff_elem" type="text" name="ff_nm_Countryofresidence[]" value="" id="ff_elem94"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap95">
        <label id="bfLabel95" for="ff_elem95">Telephone (home)<span class="bfRequired">*</span> 
        </label>
        <input class="ff_elem" type="text" name="ff_nm_Telephone[]" value="" id="ff_elem95"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap96">
        <label id="bfLabel96" for="ff_elem96">Mobile no</label>
        <input class="ff_elem" type="text" name="ff_nm_Mobileno[]" value="" id="ff_elem96"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap101">
        <label id="bfLabel101" for="ff_elem101">Email address</label>
        <input class="ff_elem" type="text" name="ff_nm_email[]" value="" id="ff_elem101"/>
        </section>
        </fieldset></div></div></div><div class="bfFieldset-bl"><div class="bfFieldset-br"><div class="bfFieldset-b"></div></div></div></div><!-- bfFieldset-wrapper end -->
        <button type="button" class="bfNextButton button" type="submit" onclick="ff_validate_nextpage(this, 'click');populateSummarizers();if(typeof bfRefreshAll != 'undefined'){bfRefreshAll();}" value="Next"><span>Next</span></button>
        </div><!-- bfPage end -->
        <div id="bfPage2" class="bfPage" style="display:none;">
        <span class="bfErrorMessage" style="display:none"></span>
        <div class="bfFieldset-wrapper bfWrapperBlock bfClearfix"><div class="bfFieldset-tl"><div class="bfFieldset-tr"><div class="bfFieldset-t"></div></div></div><div class="bfFieldset-l"><div class="bfFieldset-r"><div class="bfFieldset-m bfClearfix"><fieldset class="bfBlock" id="Enrollmentinformation">
        <legend><span class="bfLegend-l"><span class="bfLegend-r"><span class="bfLegend-m">Enrollment Information</span></span></span></legend>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap128">
        <label id="bfLabel128" for="ff_elem128">Preferred year of commencement of studies<span class="bfRequired">*</span> 
        </label>
        <input class="ff_elem" type="text" name="ff_nm_Year[]" value="" id="ff_elem128"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap133">
        <label id="bfLabel133" for="ff_elem133">Intake<span class="bfRequired">*</span> 
        </label>
        <span class="bfElementGroupNoWrap" id="bfElementGroupNoWrap133">
        <input  class="ff_elem" type="checkbox" name="ff_nm_Intake[]" value="January" id="ff_elem133"/><label class="bfGroupLabel" id="bfGroupLabel133" for="ff_elem133">January</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_Intake[]" value="May" id="ff_elem133_1"/><label class="bfGroupLabel" id="bfGroupLabel133_1" for="ff_elem133_1">May</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_Intake[]" value="September" id="ff_elem133_2"/><label class="bfGroupLabel" id="bfGroupLabel133_2" for="ff_elem133_2">September</label>
        </span>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap138">
        <label id="bfLabel138" for="ff_elem138">Campus of study<span class="bfRequired">*</span> 
        </label>
        <span class="bfElementGroupNoWrap" id="bfElementGroupNoWrap138">
        <input  class="ff_elem" type="checkbox" name="ff_nm_Campus[]" value="Limuru" id="ff_elem138"/><label class="bfGroupLabel" id="bfGroupLabel138" for="ff_elem138">Main campus (Limuru)</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_Campus[]" value="Nairobi" id="ff_elem138_1"/><label class="bfGroupLabel" id="bfGroupLabel138_1" for="ff_elem138_1">Nairobi</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_Campus[]" value="Nakuru" id="ff_elem138_2"/><label class="bfGroupLabel" id="bfGroupLabel138_2" for="ff_elem138_2">Nakuru</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_Campus[]" value="Machakos" id="ff_elem138_3"/><label class="bfGroupLabel" id="bfGroupLabel138_3" for="ff_elem138_3">Machakos</label>
        </span>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap139">
        <label id="bfLabel139" for="ff_elem139">Preferred mode of study<span class="bfRequired">*</span> 
        </label>
        <span class="bfElementGroupNoWrap" id="bfElementGroupNoWrap139">
        <input  class="ff_elem" type="checkbox" name="ff_nm_Studymode[]" value="Regular" id="ff_elem139"/><label class="bfGroupLabel" id="bfGroupLabel139" for="ff_elem139">Regular/Day</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_Studymode[]" value="Evening" id="ff_elem139_1"/><label class="bfGroupLabel" id="bfGroupLabel139_1" for="ff_elem139_1">Evening</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_Studymode[]" value="Distancelearning" id="ff_elem139_2"/><label class="bfGroupLabel" id="bfGroupLabel139_2" for="ff_elem139_2">Distance learning</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_Studymode[]" value="Schoolbased" id="ff_elem139_3"/><label class="bfGroupLabel" id="bfGroupLabel139_3" for="ff_elem139_3">School Based (Education programmes)</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_Studymode[]" value="Modular" id="ff_elem139_4"/><label class="bfGroupLabel" id="bfGroupLabel139_4" for="ff_elem139_4">Modular</label>
        </span>
        </section>
        </fieldset></div></div></div><div class="bfFieldset-bl"><div class="bfFieldset-br"><div class="bfFieldset-b"></div></div></div></div><!-- bfFieldset-wrapper end -->
        <div class="bfFieldset-wrapper bfWrapperBlock bfClearfix"><div class="bfFieldset-tl"><div class="bfFieldset-tr"><div class="bfFieldset-t"></div></div></div><div class="bfFieldset-l"><div class="bfFieldset-r"><div class="bfFieldset-m bfClearfix"><fieldset class="bfBlock" id="Programmes">
        <legend><span class="bfLegend-l"><span class="bfLegend-r"><span class="bfLegend-m">Programmes</span></span></span></legend>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap153">
        <label id="bfLabel153" for="ff_elem153">PhD Programmes</label>
        <select data-chosen="no-chzn" class="ff_elem chzn-done" name="ff_nm_PhD[]" id="ff_elem153">
        <option value="">- Select PhD Program -</option>
        <option value="Doctor of Philosophy in Business Administration and Management">Doctor of Philosophy in Business Administration and Management</option>
        <option value="Doctor of Philosophy in Development Studies">Doctor of Philosophy in Development Studies</option>
        <option value="Doctor of Philosophy in Theology">Doctor of Philosophy in Theology</option>
        </select>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap154">
        <label id="bfLabel154" for="ff_elem154">Masters' Programmes</label>
        <select data-chosen="no-chzn" class="ff_elem chzn-done" name="ff_nm_Masters[]" id="ff_elem154">
        <option value="">- Select Masters Program -</option>
        <option value="Masters of Arts in Communication">Masters of Arts in Communication</option>
        <option value="Master of Arts in Community Care and HIV/AIDS">Master of Arts in Community Care and HIV/AIDS</option>
        <option value="Masters of Arts in Counseling Psychology">Masters of Arts in Counseling Psychology</option>
        <option value="Masters in Islam and Christian-Muslim Relations (ICMR)">Masters in Islam and Christian-Muslim Relations (ICMR)</option>
        <option value="Masters of Arts in Sociology">Masters of Arts in Sociology</option>
        <option value="Masters of Arts in Transformational Leadership">Masters of Arts in Transformational Leadership</option>
        <option value="Masters of Business Administration (MBA)">Masters of Business Administration (MBA)</option>
        <option value="Masters of Development Studies (MDS)">Masters of Development Studies (MDS)</option>
        <option value="Master of Education (Early Childhood Studies)">Master of Education (Early Childhood Studies)</option>
        <option value="Masters of Procurement and Logistics Management">Masters of Procurement and Logistics Management</option>
        <option value="Masters of Public Administration and Policy">Masters of Public Administration and Policy</option>
        <option value="Masters of Theology">Masters in Theology</option>
        </select>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap159">
        <label id="bfLabel159" for="ff_elem159">Undergraduate Programmes</label>
        <select data-chosen="no-chzn" class="ff_elem chzn-done" name="ff_nm_Undergraduate[]" id="ff_elem159">
        <option value="">- Select Undergraduate Program -</option>
        <option value="Bachelor of Arts in Communication">Bachelor of Arts in Communication</option>
        <option value="Bachelor of Arts in Community Development">Bachelor of Arts in Community Development</option>
        <option value="Bachelor of Arts in Counseling Psychology">Bachelor of Arts in Counseling Psychology</option>
        <option value="Bachelor of Arts in Criminal Justice and Security Studies">Bachelor of Arts in Criminal Justice and Security Studies</option>
        <option value="Bachelor of Arts in Leadership and Management">Bachelor of Arts in Leadership and Management</option>
        <option value="Bachelor of Arts in Peace &amp; Conflict Studies">Bachelor of Arts in Peace &amp; Conflict Studies</option>
        <option value="Bachelor of Arts in Social Work">Bachelor of Arts in Social Work</option>
        <option value="Bachelor of Business Administration &amp; Management">Bachelor of Business Administration &amp; Management</option>
        <option value="Bachelor of Business and Information Technology">Bachelor of Business and Information Technology</option>
        <option value="Bachelor of Commerce">Bachelor of Commerce</option>
        <option value="Bachelor of Science in Computer Science">Bachelor of Science in Computer Science</option>
        <option value="Bachelor of Divinity">Bachelor of Divinity</option>
        <option value="Bachelor of Education (Arts)">Bachelor of Education (Arts)</option>
        <option value="Bachelor of Education in Early Childhood Development and Education">Bachelor of Education in Early Childhood Development and Education</option>
        <option value="Bachelor of Education (Special Needs)">Bachelor of Education (Special Needs)</option>
        <option value="Bachelor of Science in Computing and Information Systems">Bachelor of Science in Computing and Information Systems</option>
        <option value="Bachelor of Science in Health Records Management and Informatics">Bachelor of Science in Health Records Management and Informatics</option>
        <option value="Bachelor of Science in Health Systems Management and Economics">Bachelor of Science in Health Systems Management and Economics</option>
        <option value="Bachelor of Science in Nursing (Regular)">Bachelor of Science in Nursing (Regular)</option>
        </select>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap164">
        <label id="bfLabel164" for="ff_elem164">Diploma Programmes</label>
        <select data-chosen="no-chzn" class="ff_elem chzn-done" name="ff_nm_Diploma[]" id="ff_elem164">
        <option value="">- Select Diploma-</option>
        <option value="Diploma in Business Management">Diploma in Business Management</option>
        <option value="Diploma in Business and Information Technology">Diploma in Business and Information Technology</option>
        <option value="Diploma in Clinical Medicine and Surgery">Diploma in Clinical Medicine and Surgery</option>
        <option value="Diploma in Communication">Diploma in Communication</option>
        <option value="Diploma in Community Development">Diploma in Community Development</option>
        <option value="Diploma in Community Health Development">Diploma in Community Health Development</option>
        <option value="Diploma in Computer Science">Diploma in Computer Science</option>
        <option value="Diploma in Counseling Psychology">Diploma in Counseling Psychology</option>
        <option value="Diploma in Criminology and Security Management">Diploma in Criminology and Security Management</option>
        <option value="Diploma in Education (Arts)">Diploma in Education (Arts)</option>
        <option value="Diploma in Education (Early Childhood Education)">Diploma in Education (Early Childhood Studies)</option>
        <option value="Diploma in Film Production">Diploma in Film Production</option>
        <option value="Diploma in Health Records Management">Diploma in Health Records Management</option>
        <option value="Diploma in Hotel and Catering Management">Diploma in Hotel and Catering Management</option>
        <option value="Diploma in Information Technology">Diploma in Information Technology</option>
        <option value="Diploma in Journalism">Diploma in Journalism</option>
        <option value="Diploma in Leadership and Mnagement">Diploma in Leadership and Management</option>
        <option value="Diploma in Music">Diploma in Music</option>
        <option value="Diploma in Public Relations">Diploma in Public Relations</option>
        <option value="Diploma in Sign Language">Diploma in Sign Language</option>
        <option value="Diploma in Social Work">Diploma in Social Work</option>
        <option value="Diploma in Theology">Diploma in Theology</option>
        </select>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap140">
        <label id="bfLabel140" for="ff_elem140">Certificate programmes</label>
        <select data-chosen="no-chzn" class="ff_elem chzn-done" name="ff_nm_Certificate_programmes[]" id="ff_elem140">
        <option value="">- Select Certificate -</option>
        <option value="Certificate in Business Information Technology">Certificate in Business Information Technology</option>
        <option value="Certificate in Business Management">Certificate in Business Management</option>
        <option value="Certificate in Computer Science">Certificate in Computer Science</option>
        <option value="Certificate in Communication">Certificate in Communication</option>
        <option value="Certificate in Community Development">Certificate in Community Development</option>
        <option value="Certificate in Criminology and Security Management">Certificate in Criminology and Security Management</option>
        <option value="Certificate in Higher Education Instructional Design">Certificate in Higher Education Instructional Design</option>
        <option value="Certificate in Information Technology">Certificate in Information Technology</option>
        <option value="Certificate in Music">Certificate in Music</option>
        <option value="Certificate in Theology">Certificate in Theology</option>
        </select>
        </section>
        </fieldset></div></div></div><div class="bfFieldset-bl"><div class="bfFieldset-br"><div class="bfFieldset-b"></div></div></div></div><!-- bfFieldset-wrapper end -->
        <div class="bfFieldset-wrapper bfWrapperBlock bfClearfix"><div class="bfFieldset-tl"><div class="bfFieldset-tr"><div class="bfFieldset-t"></div></div></div><div class="bfFieldset-l"><div class="bfFieldset-r"><div class="bfFieldset-m bfClearfix"><fieldset class="bfBlock" id="Education">
        <legend><span class="bfLegend-l"><span class="bfLegend-r"><span class="bfLegend-m">Education Information</span></span></span></legend>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap165">
        <label id="bfLabel165" for="ff_elem165">Please list all your previously attended schools, colleges, universities. Don't list primary schoolsent<span class="bfRequired">*</span> 
        </label>
        <textarea cols="20" rows="5" class="ff_elem" name="ff_nm_Previousschools[]" id="ff_elem165"></textarea>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap166">
        <label id="bfLabel166" for="ff_elem166">KCSE Index number<span class="bfRequired">*</span> 
        </label>
        <input class="ff_elem" type="text" name="ff_nm_KCSEIndexnumber[]" value="" id="ff_elem166"/>
        </section>
        </fieldset></div></div></div><div class="bfFieldset-bl"><div class="bfFieldset-br"><div class="bfFieldset-b"></div></div></div></div><!-- bfFieldset-wrapper end -->
        <div class="bfFieldset-wrapper bfWrapperBlock bfClearfix"><div class="bfFieldset-tl"><div class="bfFieldset-tr"><div class="bfFieldset-t"></div></div></div><div class="bfFieldset-l"><div class="bfFieldset-r"><div class="bfFieldset-m bfClearfix"><fieldset class="bfBlock" id="Academic Credentials">
        <legend><span class="bfLegend-l"><span class="bfLegend-r"><span class="bfLegend-m">Academic Credentials</span></span></span></legend>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap167">
        <label id="bfLabel167" for="ff_elem167">Upload your high school certificate<span class="bfRequired">*</span> 
        </label>
        <input class="ff_elem" type="file" name="ff_nm_Highschool[]" id="ff_elem167"/>
        <span id="ff_elem167_files"></span></section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap168">
        <label id="bfLabel168" for="ff_elem168">Upload College certificate (if any)</label>
        <input class="ff_elem" type="file" name="ff_nm_Collegecertificates[]" id="ff_elem168"/>
        <span id="ff_elem168_files"></span></section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap169">
        <label id="bfLabel169" for="ff_elem169">Upload other academic papers</label>
        <input class="ff_elem" type="file" name="ff_nm_Otherpaers[]" id="ff_elem169"/>
        <span id="ff_elem169_files"></span></section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap174">
        <label id="bfLabel174" for="ff_elem174">Are you an alumnus of St. Paul's<span class="bfRequired">*</span> 
        </label>
        <span class="bfElementGroupNoWrap" id="bfElementGroupNoWrap174">
        <input  class="ff_elem" type="checkbox" name="ff_nm_Alumnus[]" value="Yes" id="ff_elem174"/><label class="bfGroupLabel" id="bfGroupLabel174" for="ff_elem174">Yes</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_Alumnus[]" value="No" id="ff_elem174_1"/><label class="bfGroupLabel" id="bfGroupLabel174_1" for="ff_elem174_1">No</label>
        </span>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap175">
        <label id="bfLabel175" for="ff_elem175">If yes, indicate year of graduation and programme</label>
        <input class="ff_elem" type="text" name="ff_nm_Graduation[]" value="" id="ff_elem175"/>
        </section>
        </fieldset></div></div></div><div class="bfFieldset-bl"><div class="bfFieldset-br"><div class="bfFieldset-b"></div></div></div></div><!-- bfFieldset-wrapper end -->
        <div class="bfNoSection" id="Postage">
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap180">
        <label id="bfLabel180" for="ff_elem180">Send my admission letter to</label>
        <span class="bfElementGroupNoWrap" id="bfElementGroupNoWrap180">
        <input checked="checked"  class="ff_elem" type="radio" name="ff_nm_postage[]" value="Limuru Campus" id="ff_elem180"/><label class="bfGroupLabel" id="bfGroupLabel180" for="ff_elem180">Limuru Campus</label>
        <input  class="ff_elem" type="radio" name="ff_nm_postage[]" value="Nairobi Campus" id="ff_elem180_1"/><label class="bfGroupLabel" id="bfGroupLabel180_1" for="ff_elem180_1">Nairobi Campus</label>
        <input  class="ff_elem" type="radio" name="ff_nm_postage[]" value="Nakuru Campus" id="ff_elem180_2"/><label class="bfGroupLabel" id="bfGroupLabel180_2" for="ff_elem180_2">Nakuru Campus</label>
        <input  class="ff_elem" type="radio" name="ff_nm_postage[]" value="Machakos Campus" id="ff_elem180_3"/><label class="bfGroupLabel" id="bfGroupLabel180_3" for="ff_elem180_3">Machakos Campus</label>
        <input  class="ff_elem" type="radio" name="ff_nm_postage[]" value="My Postal Address" id="ff_elem180_4"/><label class="bfGroupLabel" id="bfGroupLabel180_4" for="ff_elem180_4">My Postal Address</label>
        <input  class="ff_elem" type="radio" name="ff_nm_postage[]" value="My Email Address" id="ff_elem180_5"/><label class="bfGroupLabel" id="bfGroupLabel180_5" for="ff_elem180_5">My Email Address</label>
        </span>
        </section>
        </div>
        <div class="bfNoSection" id="Application">
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap181">
        <label id="bfLabel181" for="ff_elem181">Please attach a scanned copy of your bank slip</label>
        <input class="ff_elem" type="file" name="ff_nm_Appfee[]" id="ff_elem181"/>
        <span id="ff_elem181_files"></span></section>
        </div>
        <button type="button" class="bfPrevButton button" type="submit" onclick="ff_validate_prevpage(this, 'click');populateSummarizers();if(typeof bfRefreshAll != 'undefined'){bfRefreshAll();}" value="Back"><span>Back</span></button>
        <button type="button" class="bfNextButton button" type="submit" onclick="ff_validate_nextpage(this, 'click');populateSummarizers();if(typeof bfRefreshAll != 'undefined'){bfRefreshAll();}" value="Next"><span>Next</span></button>
        </div><!-- bfPage end -->
        <div id="bfPage3" class="bfPage" style="display:none;">
        <span class="bfErrorMessage" style="display:none"></span>
        <div class="bfFieldset-wrapper bfWrapperBlock bfClearfix"><div class="bfFieldset-tl"><div class="bfFieldset-tr"><div class="bfFieldset-t"></div></div></div><div class="bfFieldset-l"><div class="bfFieldset-r"><div class="bfFieldset-m bfClearfix"><fieldset class="bfBlock" id="Details of next of Kin">
        <legend><span class="bfLegend-l"><span class="bfLegend-r"><span class="bfLegend-m">Details of Next of Kin</span></span></span></legend>
        <section class="bfSectionDescription">
        <p>Details of Next of Kin</p>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap246">
        <label id="bfLabel246" for="ff_elem246">Name</label>
        <input class="ff_elem" type="text" name="ff_nm_Namenextofkin[]" value="" id="ff_elem246"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap247">
        <label id="bfLabel247" for="ff_elem247">Relationship to Applicant</label>
        <input class="ff_elem" type="text" name="ff_nm_Relationshipnextofkin[]" value="" id="ff_elem247"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap248">
        <label id="bfLabel248" for="ff_elem248">Address</label>
        <input class="ff_elem" type="text" name="ff_nm_Addressnextofkin[]" value="" id="ff_elem248"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap249">
        <label id="bfLabel249" for="ff_elem249">Telephone</label>
        <input class="ff_elem" type="text" name="ff_nm_Telephonenextofkin[]" value="" id="ff_elem249"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap250">
        <label id="bfLabel250" for="ff_elem250">Email</label>
        <input class="ff_elem" type="text" name="ff_nm_Emailnextofkin[]" value="" id="ff_elem250"/>
        </section>
        </fieldset></div></div></div><div class="bfFieldset-bl"><div class="bfFieldset-br"><div class="bfFieldset-b"></div></div></div></div><!-- bfFieldset-wrapper end -->
        <div class="bfFieldset-wrapper bfWrapperBlock bfClearfix"><div class="bfFieldset-tl"><div class="bfFieldset-tr"><div class="bfFieldset-t"></div></div></div><div class="bfFieldset-l"><div class="bfFieldset-r"><div class="bfFieldset-m bfClearfix"><fieldset class="bfBlock" id="employment">
        <legend><span class="bfLegend-l"><span class="bfLegend-r"><span class="bfLegend-m">Employment details and referees</span></span></span></legend>
        <section class="bfSectionDescription">
        <p><strong>Kindly note that this section will be filled by applicants for Masters' and PhD programmes.</strong></p>
        </section>
        </fieldset></div></div></div><div class="bfFieldset-bl"><div class="bfFieldset-br"><div class="bfFieldset-b"></div></div></div></div><!-- bfFieldset-wrapper end -->
        <div class="bfNoSection" id="Employment">
        <section class="bfSectionDescription">
        <p><strong>Please give details of your current employment, this information will be used to assess your relevant experience.</strong></p>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap194">
        <label id="bfLabel194" for="ff_elem194">Company/Organisation/Employer Name</label>
        <input class="ff_elem" type="text" name="ff_nm_Employer[]" value="" id="ff_elem194"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap195">
        <label id="bfLabel195" for="ff_elem195">Job title</label>
        <input class="ff_elem" type="text" name="ff_nm_Jobtitle[]" value="" id="ff_elem195"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap196">
        <label id="bfLabel196" for="ff_elem196">Date of Commencement</label>
        <input class="ff_elem" type="text" name="ff_nm_Commencement[]" value="" id="ff_elem196"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap197">
        <label id="bfLabel197" for="ff_elem197">Full time/ Part time</label>
        <span class="bfElementGroupNoWrap" id="bfElementGroupNoWrap197">
        <input  class="ff_elem" type="checkbox" name="ff_nm_Fulltime[]" value="Full time" id="ff_elem197"/><label class="bfGroupLabel" id="bfGroupLabel197" for="ff_elem197">Full time</label>
        <input  class="ff_elem" type="checkbox" name="ff_nm_Fulltime[]" value="Part time" id="ff_elem197_1"/><label class="bfGroupLabel" id="bfGroupLabel197_1" for="ff_elem197_1">Part time</label>
        </span>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap198">
        <label id="bfLabel198" for="ff_elem198">Key Responsibilities and achievements</label>
        <input class="ff_elem" type="text" name="ff_nm_Responsibilities[]" value="" id="ff_elem198"/>
        </section>
        </div>
        <div class="bfNoSection" id="Academicreferee">
        <section class="bfSectionDescription">
        <p><strong>Academic Referee</strong></p>
        <p><em>(The referee must have taught you in the undergraduate, post-graduate or professional programmes) </em></p>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap199">
        <label id="bfLabel199" for="ff_elem199">Name</label>
        <input class="ff_elem" type="text" name="ff_nm_NameAcademicRef[]" value="" id="ff_elem199"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap200">
        <label id="bfLabel200" for="ff_elem200">Position</label>
        <input class="ff_elem" type="text" name="ff_nm_PositionAcademicRef[]" value="" id="ff_elem200"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap209">
        <label id="bfLabel209" for="ff_elem209">Telephone number</label>
        <input class="ff_elem" type="text" name="ff_nm_TelAcademicRef[]" value="" id="ff_elem209"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap210">
        <label id="bfLabel210" for="ff_elem210">Email Address</label>
        <input class="ff_elem" type="text" name="ff_nm_EmailaddressAcademicRef[]" value="" id="ff_elem210"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap211">
        <label id="bfLabel211" for="ff_elem211">Postal Address</label>
        <input class="ff_elem" type="text" name="ff_nm_PostaladdressAcademicRef[]" value="" id="ff_elem211"/>
        </section>
        </div>
        <div class="bfNoSection" id="Religiousref">
        <section class="bfSectionDescription">
        <p><strong>Religious Referee</strong></p>
        <p> </p>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap216">
        <label id="bfLabel216" for="ff_elem216">Name</label>
        <input class="ff_elem" type="text" name="ff_nm_NameReligiousref[]" value="" id="ff_elem216"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap217">
        <label id="bfLabel217" for="ff_elem217">Position</label>
        <input class="ff_elem" type="text" name="ff_nm_PositionReligiousref[]" value="" id="ff_elem217"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap218">
        <label id="bfLabel218" for="ff_elem218">Telephone number</label>
        <input class="ff_elem" type="text" name="ff_nm_TelephoneReligiousref[]" value="" id="ff_elem218"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap219">
        <label id="bfLabel219" for="ff_elem219">Email Address</label>
        <input class="ff_elem" type="text" name="ff_nm_EmailReligiousref[]" value="" id="ff_elem219"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap220">
        <label id="bfLabel220" for="ff_elem220">Postal Address</label>
        <input class="ff_elem" type="text" name="ff_nm_PostaladdressReligiousref[]" value="" id="ff_elem220"/>
        </section>
        </div>
        <div class="bfNoSection" id="Professionalreferee  ">
        <section class="bfSectionDescription">
        <p><strong>Professional Referee</strong></p>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap225">
        <label id="bfLabel225" for="ff_elem225">Name</label>
        <input class="ff_elem" type="text" name="ff_nm_NameProfessionalRef[]" value="" id="ff_elem225"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap226">
        <label id="bfLabel226" for="ff_elem226">Position</label>
        <input class="ff_elem" type="text" name="ff_nm_PositionProfessionalRef[]" value="" id="ff_elem226"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap227">
        <label id="bfLabel227" for="ff_elem227">Telephone number</label>
        <input class="ff_elem" type="text" name="ff_nm_TelProfessionalRef[]" value="" id="ff_elem227"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap228">
        <label id="bfLabel228" for="ff_elem228">Email Address</label>
        <input class="ff_elem" type="text" name="ff_nm_EmailProfessionalRef[]" value="" id="ff_elem228"/>
        </section>
        <section class="bfElemWrap bfLabelLeft" id="bfElemWrap229">
        <label id="bfLabel229" for="ff_elem229">Postal Address</label>
        <input class="ff_elem" type="text" name="ff_nm_PostaladdressProfessionalRef[]" value="" id="ff_elem229"/>
        </section>
        </div>
        <button type="button" class="bfPrevButton button" type="submit" onclick="ff_validate_prevpage(this, 'click');populateSummarizers();if(typeof bfRefreshAll != 'undefined'){bfRefreshAll();}" value="Back"><span>Back</span></button>
        <button class="bfCancelButton button" type="submit" onclick="ff_resetForm(this, 'click');"  value="Reset"><span>Reset</span></button>
        <button type="button" id="bfSubmitButton" class="bfSubmitButton button" onclick="if(typeof bf_htmltextareainit != 'undefined'){ bf_htmltextareainit() }if(document.getElementById('bfPaymentMethod')){document.getElementById('bfPaymentMethod').value='';};ff_validate_submit(this, 'click');" value="Submit"><span>Submit</span></button>
        </div><!-- bfPage end -->
        <div id="bfPage4" class="bfPage" style="display:none;">
        <span class="bfErrorMessage" style="display:none"></span>
        <div class="bfNoSection" id="Thankyou">
        <section class="bfSectionDescription">
        <p>Thank you for submitting your application. We shall get back to you within the shortest time possible.</p>
        </section>
        </div>
        </div>
        <noscript>Please turn on javascript to submit your data. Thank you!</noscript>
        <input type="hidden" name="ff_contentid" value="0"/>
        <input type="hidden" name="ff_applic" value=""/>
        <input type="hidden" name="ff_record_id" value=""/>
        <input type="hidden" name="ff_module_id" value="0"/>
        <input type="hidden" name="ff_form" value="1"/>
        <input type="hidden" name="ff_task" value="submit"/>
        <input type="hidden" name="option" value="com_breezingforms"/>
        <input type="hidden" name="Itemid" value="410"/>
        </form>

</body>
</html>