<?php

//configure JSON response
$response = [
    'top_err' =>'' ,
    'top_success' => '',
    'to_err' => '',
    'subject_err' => '',
    'message_err' => ''
    
];

try{
    $mail = newPHPMailer();
    $mail->isSMTP();
    $mail->Host = $_SERVER['HTTP_PHP_MAILER_HOST'];
    $mail->SMTPAuth = true;
    $mail->Port = $_SERVER['HTTP_PHP_MAILER_PORT'];
    $mail->Username = $_SERVER['HTTP_PHP_MAILER_USERNAME'];
    $mail->Password = $_SERVER['HTTP_PHP_MAILER_PASSWORD'];
}
catch(Exception $e){
    $response['top_err'] = 'sorry. There was a problem sending your email';
    exit(json_encode($response));
}


$contentType = isset($_SERVER['CONTENT_TYPE']) ? trim($_SERVER['CONTENT_TYPE']):
'';

if($contentType == 'application/json'){
    $content = trim(file_get_contents(('php://input')));
    //convert content into PHP Array
    $decoded = json_decode($content, true);
    if(is_array($decoded)){
        exit(json_encode($decoded));

        //Sanitize Input Data
        foreach($decoded as $name => $value){
            $decoded[$name] = trim(filter_var($value, FILTER_SANITIZE_STRING));
        }

        //Error checking
        if(empty($decoded['to'])){
            $response['to_err'] = 'Error. This input cannot be empty.';

        }
        else if(!filter_var($decoded['to'], FILTER_VALIDATE_EMAIL)){
            $response['to_err'] = 'Error. Input must be a valid email.';

        }
        if(empty($decoded['subject'])){
            $response['subject_err'] = 'Error. This input cannot be empty. ';
        }
        if(empty($decoded['message'])){
            $response['message_err'] = 'Error. This input cannot be empty. ';

        }
        //Can't send the email if we already have a response to show

        foreach($response as $type => $message){
            if(!empty($response[$type])){
                exit(json_encode($response));
            }
        }

        //SEND MAIL NOW
        try{
            $mail-> setFrom('robisen001@gmail.com');
            $mail-> Subject = $decoded['subject'];
            $mail -> isHTML(true);
            $mail-> Body = '<p>'.$decoded['message'].'</p>';
            $mail-> addAddress($decoded['to']);
            $mail-> send();
        }
        catch(Exception $e){
            $response['top_err'] = 'sorry. There was a problem sending your email';
            exit(json_encode($response));
        }

        //Success Feedback
        $response['top_success'] = 'Success. Message has been sent.';
        exit(json_encode($response));
    }

}
$response['top_err'] = 'sorry. there was a problem sending your email';
exit(json_encode($response));
?>