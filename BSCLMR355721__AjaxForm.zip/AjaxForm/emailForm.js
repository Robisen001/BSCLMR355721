const emailForm = document.querySelector('.email-form');

emailForm.onsubmit = e => {
    e.preventDefault();
    let toInput = emailForm.querySelector('input[name="to"]');
    let subjectInput = emailForm.querySelector('input[name= "subject"]');
    let messageInput = emailForm.querySelector('textarea[name = "message"]');

    // Make POST request

    fetch('libraries/sendEmailForm.php',{
        method: 'POST',
        headers:{'content-type':'application/json'},
        mode: 'same-origin',
        credentials: 'same-origin',
        body: JSON.stringify({
            to: toInput.nodeValue,
            subject: subjectInput.nodeValue,
            message: messageInput.value
        })
    }).then(json => json.json()).then(res =>{
        console.log(res);
        if[(res['to_err'])]{
            toInput.insertAdjacentHTML('beforebegin', '<p 
            class="email-form_error-msg">${res['to_err']} </p>');
        }
    });

}