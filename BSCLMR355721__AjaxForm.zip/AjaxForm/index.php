<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajax Form Send Mail</title>
</head>
<body>
    <h1 class="title">Send Mail</h1>
    <form class="email-form">
        <label for="to">To: </label>
        <input type="text" name="to" class="email-form_text">
        <label for="subject">Subject: </label>
        <input type="text" name="subject" class="email-form_text">
        <label for="message">Message:</label>
        <textarea name="message" class="email-form__textarea"></textarea>
        <button type="submit" class="email-form_submit">Send</button>
    </form>

    <script src="email.js"></script>
</body>
</html>