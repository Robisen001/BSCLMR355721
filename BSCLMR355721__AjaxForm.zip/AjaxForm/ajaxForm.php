<?php
//using date object
$msg = date("d-m-Y");
print "<?xml>";
print "<message>$msg</message>";
?>